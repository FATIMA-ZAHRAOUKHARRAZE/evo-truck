<h2>Nouvelle demande de devis</h2>
<ul>
    <li><strong>Nom :</strong> {{ $data['name'] }}</li>
    <li><strong>Société :</strong> {{ $data['société'] }}</li>
    <li><strong>Activité :</strong> {{ $data['activité'] }}</li>
    <li><strong>Téléphone :</strong> {{ $data['phone'] }}</li>
    <li><strong>Email :</strong> {{ $data['email'] }}</li>
    <li><strong>Pays :</strong> {{ $data['country'] }}</li>
    <li><strong>Catégorie :</strong> {{ $data['prod_cat'] }}</li>
    <li><strong>Modèle :</strong> {{ $data['prod_mod'] }}</li>
    <li><strong>Message :</strong> {{ $data['message'] }}</li>
</ul>
