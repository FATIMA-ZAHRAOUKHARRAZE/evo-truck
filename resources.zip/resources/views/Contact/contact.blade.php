<x-mail::message>
# Introduction
<h3>Nom:{{ $data['Nom'] }}</h3>
<h3>Sujet:{{ $data['Sujet'] }}</h3>
<h3>Email:{{ $data['Email'] }}</h3>
<h3>Message:{{ $data['Message'] }}</h3>
EVO MACHINERY<br>
</x-mail::message>
